#pragma once
#include <Arduino.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

class DisplayHelper
{
public:
    DisplayHelper();
    void begin();
    void setLine(uint8_t line, const String &text);
    void setScrollingLine(uint8_t line, const String &text, unsigned long delay = 300);
    void clearScrolling(uint8_t line);
    void show();

private:
    LiquidCrystal_I2C lcd;
    String lines[4];
    String lastLines[4];

    struct ScrollData
    {
        String text;
        size_t pos = 0;
        unsigned long lastUpdate = 0;
        unsigned long delay = 300;
        bool enabled = false;
    };

    ScrollData scroll[4];
    void defineCustomUmlauts();
    void printWithUmlaut(const String &text);
    String getScrollView(uint8_t line);
};
