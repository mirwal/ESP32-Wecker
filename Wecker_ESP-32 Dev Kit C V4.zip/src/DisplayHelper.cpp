#include "DisplayHelper.h"
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

DisplayHelper::DisplayHelper() : lcd(0x27, 20, 4) {}

void DisplayHelper::begin()
{
    lcd.init();
    lcd.backlight();
    defineCustomUmlauts(); // ← Umlaute registrieren
    for (int i = 0; i < 4; i++)
    {
        lines[i] = "";
        lastLines[i] = "";
    }
}
String padRight(const String &input, size_t length)
{
    String result = input;
    while (result.length() < length)
    {
        result += ' ';
    }
    if (result.length() > length)
    {
        result = result.substring(0, length);
    }
    return result;
}

void DisplayHelper::setLine(uint8_t line, const String &text)
{
    if (line < 4)
    {
        lines[line] = text; // Nur speichern – Padding macht printWithUmlaut()
        scroll[line].enabled = false;
    }
}

void DisplayHelper::setScrollingLine(uint8_t line, const String &text, unsigned long delay)
{
    if (line < 4)
    {
        scroll[line].text = text + "    ";
        scroll[line].pos = 0;
        scroll[line].delay = delay;
        scroll[line].lastUpdate = millis();
        scroll[line].enabled = true;
    }
}

void DisplayHelper::clearScrolling(uint8_t line)
{
    if (line < 4)
    {
        scroll[line].enabled = false;
    }
}

String DisplayHelper::getScrollView(uint8_t line)
{
    ScrollData &s = scroll[line];
    unsigned long now = millis();

    if (now - s.lastUpdate >= s.delay)
    {
        s.pos++;
        if (s.pos > s.text.length())
            s.pos = 0;
        s.lastUpdate = now;
    }

    String view = s.text.substring(s.pos, s.pos + 20);
    if (view.length() < 20)
        view += s.text.substring(0, 20 - view.length());

    return view;
}
void DisplayHelper::defineCustomUmlauts()
{
    // https://maxpromer.github.io/LCD-Character-Creator/
    byte aeChar[8] = {
        B01010, B00000, B01110, B00001, B01111, B10001, B01111, B00000};
    byte oeChar[8] = {
        B01010, B00000, B01110, B10001, B10001, B10001, B01110, B00000};
    byte ueChar[8] = {
        B01010, B00000, B10001, B10001, B10001, B10011, B01101, B00000};
    byte ssChar[8] = {
        B00000, B00000, B01100, B10010, B10100, B10010, B10100, B10000};

    lcd.createChar(0, aeChar);
    lcd.createChar(1, oeChar);
    lcd.createChar(2, ueChar);
    lcd.createChar(3, ssChar);
}

void DisplayHelper::printWithUmlaut(const String &text)
{
    uint8_t col = 0;
    int i = 0;

    while (col < 20 && i < text.length())
    {
        uint8_t c = text[i];
        
        if (c == 0x00) { lcd.write(0); i++; col++; continue; } // ä
        if (c == 0x01) { lcd.write(1); i++; col++; continue; } // ö
        if (c == 0x02) { lcd.write(2); i++; col++; continue; } // ü
        if (c == 0x03) { lcd.write(3); i++; col++; continue; } // ß

        if (i + 1 < text.length() && (uint8_t)c == 0xC3)
        {
            uint8_t next = text[i + 1];

            if (next == 0xA4)
            {
                lcd.write(0);
                i += 2;
            }
            else if (next == 0xB6)
            {
                lcd.write(1);
                i += 2;
            }
            else if (next == 0xBC)
            {
                lcd.write(2);
                i += 2;
            }
            else if (next == 0x9F)
            {
                lcd.write(3);
                i += 2;
            }
            else
            {
                lcd.print((char)c);
                i++;
            }
        }
        else
        {
            lcd.print((char)c);
            i++;
        }
        col++;
    }

    while (col < 20)
    {
        lcd.print(" ");
        col++;
    }
}

void DisplayHelper::show()
{
    for (int i = 0; i < 4; i++)
    {
        String displayText;
        if (scroll[i].enabled)
        {
            displayText = getScrollView(i);
        }
        else
        {
            displayText = lines[i];
        }

        if (displayText != lastLines[i])
        {
            lcd.setCursor(0, i);
            printWithUmlaut(displayText);
            lastLines[i] = displayText;
            Serial.println("-" + displayText + "-");
        }
    }
}
